﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Web_Browser.Properties;

namespace Web_Browser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            var url = searchTextBox.Text;
            SearchUrl(url);
            if(!BrowserHelper.safeMode)
                BrowserHelper.history.Add(url);
        }

        private void SearchUrl(string url)
        {
            responseRichTextBox.Text = "Searching...";

            var browserHelper = new BrowserHelper();
            var result = browserHelper.Search(url);

            var responseText = result.httpResponseString;
            var response = result.httpResponse;
            var responseCode = string.Empty;

            if (response?.StatusCode != null)
            {
                responseCode = (int)response.StatusCode + " " + response.StatusCode.ToString();
                this.Text = responseCode;
            }
            else
                this.Text = "Browser";

            responseRichTextBox.Text = responseText;
        }

        private void homeToolStripButton_Click(object sender, EventArgs e)
        {
            var homeUrl = BrowserHelper.homeUrl;
            searchTextBox.Text = homeUrl;
            SearchUrl(homeUrl);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var browserHelper = new BrowserHelper();
            browserHelper.LoadData();

            var homeUrl = BrowserHelper.homeUrl;
            searchTextBox.Text = homeUrl;
            SearchUrl(homeUrl);
            homeUrlToolStripTextBox.Text = homeUrl;
        }

        private void reloadToolStripButton_Click(object sender, EventArgs e)
        {
            var url = searchTextBox.Text;
            SearchUrl(url);
        }

        private void favouriteToolStripButton_Click(object sender, EventArgs e)
        {
            BrowserHelper.favourite.Add(searchTextBox.Text);
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var homeUrl = BrowserHelper.homeUrl;
            searchTextBox.Text = homeUrl;
            SearchUrl(homeUrl);
        }

        private void reloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var url = searchTextBox.Text;
            SearchUrl(url);
        }

        private void addToFavouriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BrowserHelper.favourite.Add(searchTextBox.Text);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            var browserHelper = new BrowserHelper();
            browserHelper.SaveData();
        }

        private void safemodeToolStripLabel_Click(object sender, EventArgs e)
        {
            var safeMode = BrowserHelper.safeMode;
            if (!safeMode)
            {
                BrowserHelper.safeMode = true;
                safemodeToolStripLabel.Text = "Disable Safe Mode";
            }
            else
            {
                BrowserHelper.safeMode = false;
                safemodeToolStripLabel.Text = "Enable Safe Mode";
            }

        }

        private void historyListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            responseRichTextBox.Text = string.Empty;
            foreach (var history in BrowserHelper.history)
            {
                responseRichTextBox.Text = responseRichTextBox.Text + "\n" + history;
            }
        }

        private void favouriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            responseRichTextBox.Text = string.Empty;
            foreach (var favourite in BrowserHelper.favourite)
            {
                responseRichTextBox.Text = responseRichTextBox.Text + "\n" + favourite;
            }
        }

        private void saveHomeUrlToolStripButton2_Click(object sender, EventArgs e)
        {
            BrowserHelper.homeUrl = homeUrlToolStripTextBox.Text;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            var dialogResult = openFileDialog.ShowDialog();
            string filename;
            string[] filelines = null;
            if (dialogResult == DialogResult.OK)
            {
                filename = openFileDialog.FileName;
                filelines = File.ReadAllLines(filename);
            }
            if(filelines != null)
            {
                var browserHelper = new BrowserHelper();
                responseRichTextBox.Text = string.Empty;
                foreach (var url in filelines)
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        var result = browserHelper.Search(url);
                        var response = result.httpResponse;
                        var statusCode = (int)response.StatusCode + " " + response.StatusCode.ToString();
                        var resposeByte = response.ContentLength;

                        responseRichTextBox.Text += "\n" + statusCode + " " + resposeByte + " " + url;
                    }
                    
                }
            }
            
        }

        private void openFileDialog_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
