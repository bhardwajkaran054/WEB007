﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Collections.Specialized;

namespace Web_Browser
{
    public class BrowserHelper
    {
        public static StringCollection history = new StringCollection();
        public static StringCollection favourite = new StringCollection();
        public static string homeUrl = string.Empty;
        public static bool safeMode = false;
        public HttpResponse Search(string url)
        {
            return GetHTTPRequest(url);
        }

        public void LoadData() 
        {
            homeUrl = Properties.Settings.Default.HomePageURL;
            var historyList = Properties.Settings.Default.History;
            var favouriteList = Properties.Settings.Default.Favourite;
            if (historyList?.Count > 0) { history = historyList; }
            if (favouriteList?.Count > 0) { favourite = favouriteList; }

        }

        public void SaveData()
        {
            Properties.Settings.Default.HomePageURL = homeUrl;
            Properties.Settings.Default.History = history;
            Properties.Settings.Default.Favourite = favourite;
            Properties.Settings.Default.Save();
        }

        private HttpResponse GetHTTPRequest(string url)
        {
            try
            {
                
                var request = (HttpWebRequest)WebRequest.Create(url);
                var response = (HttpWebResponse)request.GetResponse();

                string responseString;

                using (var stream = response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        responseString = reader.ReadToEnd();
                    }
                }

                var httpResponse = new HttpResponse
                {
                    httpResponse = response,
                    httpResponseString = responseString
                };
                
                return httpResponse;
            }
            catch (Exception e)
            {
                var httpResponse = new HttpResponse
                {
                    httpResponse = null,
                    httpResponseString = "Bad Request"
                };

                return httpResponse;
            }
        }
    }
}

